/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package publishingsystem;

/**
 *
 * @author lunas
 */

public class Article implements Document { 
   
   @Override 
   public Document clone() {        
        return new Article(); 
    } 
   @Override 
   public void edit() { 
       System.out.println("Editing article...");
     } 
} 