/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package publishingsystem;

/**
 *
 * @author lunas
 */


public class PublishingSystem {
    
    public static void main(String[] args) { 
       Document article = new Article(); 
    
       Document editedArticle = article.clone(); 
       
       editedArticle.edit(); 
      } 
 } 